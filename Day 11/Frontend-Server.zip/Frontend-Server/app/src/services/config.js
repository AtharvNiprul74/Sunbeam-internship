const config = {
    BASE_URL: 'http://localhost:4000'
}

export default config