
const SECRET = "dihewuiodh7483hr894yui3hfnopi4of8h489309ffreojn43e9n"

module.exports = { SECRET }